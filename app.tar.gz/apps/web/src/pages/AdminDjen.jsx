import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { AlertTriangle, CalendarCheck, CheckCircle2, Clock3, ExternalLink, RefreshCw, Scale, Trash2, XCircle } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import apiServerClient from '@/lib/apiServerClient';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

function authHeaders(json = true) {
  return {
    ...(json ? { 'Content-Type': 'application/json' } : {}),
    Authorization: pb.authStore.token || '',
  };
}

async function apiPost(path, body = {}) {
  const response = await apiServerClient.fetch(path, { method: 'POST', headers: authHeaders(), body: JSON.stringify(body) });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error || `Falha HTTP ${response.status}`);
  return payload;
}

function onlyDate(value) {
  return value ? String(value).slice(0, 10) : '';
}

function brDate(value) {
  const d = onlyDate(value);
  if (!d) return '—';
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}

function actionBadge(value) {
  if (value === 'sim') return <Badge className="bg-amber-600 hover:bg-amber-600">Ação necessária</Badge>;
  if (value === 'nao') return <Badge variant="secondary">Sem ação</Badge>;
  return <Badge variant="outline" className="border-amber-400 text-amber-700">Revisar</Badge>;
}

function urgencyBadge(value) {
  if (value === 'alta') return <Badge variant="destructive">Urgência alta</Badge>;
  if (value === 'media') return <Badge className="bg-amber-600 hover:bg-amber-600">Urgência média</Badge>;
  return <Badge variant="outline">Normal</Badge>;
}

export default function AdminDjen() {
  const { user } = useAuth();
  const [publications, setPublications] = useState([]);
  const [holidays, setHolidays] = useState([]);
  const [filter, setFilter] = useState('acao');
  const [busy, setBusy] = useState(false);
  const [busyId, setBusyId] = useState('');
  const [msg, setMsg] = useState('');
  const [editDays, setEditDays] = useState({});
  const [holidayForm, setHolidayForm] = useState({ date: '', name: '', scope: 'comarca', tribunal: '', comarca: '' });

  const load = useCallback(async () => {
    const [pubs, hs] = await Promise.all([
      pb.collection('djen_publications').getFullList({ sort: '-availability_date,-created', expand: 'process' }).catch(() => []),
      pb.collection('court_holidays').getFullList({ sort: 'date' }).catch(() => []),
    ]);
    setPublications(pubs);
    setHolidays(hs);
    setEditDays((prev) => {
      const next = { ...prev };
      pubs.forEach((p) => { if (next[p.id] == null) next[p.id] = p.deadline_days || ''; });
      return next;
    });
  }, []);

  useEffect(() => { load(); }, [load]);

  const visible = useMemo(() => publications.filter((p) => {
    if (filter === 'todos') return true;
    if (filter === 'acao') return p.action_required === 'sim' || p.action_required === 'revisar';
    if (filter === 'rascunho') return p.deadline_status === 'rascunho';
    if (filter === 'confirmado') return p.deadline_status === 'confirmado';
    if (filter === 'semacao') return p.action_required === 'nao';
    return true;
  }), [publications, filter]);

  const stats = useMemo(() => ({
    total: publications.length,
    acao: publications.filter((p) => p.action_required === 'sim').length,
    revisar: publications.filter((p) => p.action_required === 'revisar').length,
    rascunho: publications.filter((p) => p.deadline_status === 'rascunho').length,
  }), [publications]);

  const sync = async () => {
    setBusy(true); setMsg('');
    try {
      const r = await apiPost('/legal/djen/sync', { maxItems: 500 });
      setMsg(`DJEN sincronizado: ${r.found} publicação(ões) localizada(s).`);
      await load();
    } catch (e) { setMsg(e.message); }
    finally { setBusy(false); }
  };

  const recalc = async (p) => {
    const days = Number(editDays[p.id]);
    if (!days) { setMsg('Informe a quantidade de dias para recalcular o prazo.'); return; }
    setBusyId(p.id); setMsg('');
    try {
      await apiPost(`/legal/djen/${p.id}/recalculate`, { days, regime: p.regime || 'cpc' });
      await load();
      setMsg('Prazo recalculado e mantido como rascunho.');
    } catch (e) { setMsg(e.message); }
    finally { setBusyId(''); }
  };

  const confirm = async (p) => {
    if (!window.confirm(`Confirmar o prazo em ${brDate(p.deadline)} e inserir na agenda?`)) return;
    setBusyId(p.id); setMsg('');
    try {
      await apiPost(`/legal/djen/${p.id}/confirm`);
      await load();
      setMsg('Prazo confirmado e inserido na agenda.');
    } catch (e) { setMsg(e.message); }
    finally { setBusyId(''); }
  };

  const ignore = async (p) => {
    if (!window.confirm('Marcar esta publicação como sem ação e remover qualquer rascunho de prazo?')) return;
    setBusyId(p.id); setMsg('');
    try {
      await apiPost(`/legal/djen/${p.id}/ignore`);
      await load();
    } catch (e) { setMsg(e.message); }
    finally { setBusyId(''); }
  };

  const saveHoliday = async (e) => {
    e.preventDefault();
    if (!holidayForm.date || !holidayForm.name.trim()) return;
    setMsg('');
    try {
      await pb.collection('court_holidays').create({
        date: `${holidayForm.date} 12:00:00.000Z`,
        name: holidayForm.name.trim(),
        scope: holidayForm.scope,
        tribunal: holidayForm.tribunal.trim().toUpperCase(),
        comarca: holidayForm.comarca.trim(),
        source: 'Cadastro interno',
        active: true,
        responsible_user: user?.id || '',
      });
      setHolidayForm({ date: '', name: '', scope: 'comarca', tribunal: '', comarca: '' });
      await load();
      setMsg('Feriado/indisponibilidade cadastrado. Novos cálculos passarão a considerá-lo.');
    } catch (e2) { setMsg(e2?.message || 'Não foi possível cadastrar.'); }
  };

  const removeHoliday = async (id) => {
    await pb.collection('court_holidays').delete(id);
    await load();
  };

  return (
    <div className="space-y-6">
      <Helmet><title>Publicações DJEN — Área Restrita</title></Helmet>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Publicações DJEN</h1>
          <p className="mt-1 text-sm text-muted-foreground">Inbox da sua OAB com triagem, prazo em rascunho e confirmação para a agenda.</p>
          <p className="mt-1 text-xs text-muted-foreground">OAB ativa: {user?.oab_number ? `${user.oab_number}/${user?.oab_uf || ''}` : 'não cadastrada'}</p>
        </div>
        <Button onClick={sync} disabled={busy || !user?.oab_number || !user?.oab_uf}>
          <RefreshCw className={`mr-2 h-4 w-4 ${busy ? 'animate-spin' : ''}`} /> {busy ? 'Sincronizando…' : 'Sincronizar agora'}
        </Button>
      </div>

      {msg && <div className="rounded-xl border border-border bg-card p-3 text-sm">{msg}</div>}

      <div className="grid gap-3 sm:grid-cols-4">
        <div className="rounded-2xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Publicações</p><p className="mt-1 text-2xl font-bold">{stats.total}</p></div>
        <div className="rounded-2xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Ação necessária</p><p className="mt-1 text-2xl font-bold">{stats.acao}</p></div>
        <div className="rounded-2xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Revisar</p><p className="mt-1 text-2xl font-bold">{stats.revisar}</p></div>
        <div className="rounded-2xl border border-border bg-card p-4"><p className="text-xs text-muted-foreground">Prazos em rascunho</p><p className="mt-1 text-2xl font-bold">{stats.rascunho}</p></div>
      </div>

      <div className="flex flex-wrap gap-2">
        {[
          ['acao', 'Para agir/revisar'], ['rascunho', 'Prazos em rascunho'], ['confirmado', 'Confirmados'], ['semacao', 'Sem ação'], ['todos', 'Todos'],
        ].map(([v, label]) => <Button key={v} size="sm" variant={filter === v ? 'default' : 'outline'} onClick={() => setFilter(v)}>{label}</Button>)}
      </div>

      <div className="space-y-3">
        {visible.length === 0 && <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">Nenhuma publicação neste filtro.</div>}
        {visible.map((p) => (
          <article key={p.id} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  {actionBadge(p.action_required)} {urgencyBadge(p.urgency)}
                  {p.deadline_status === 'confirmado' && <Badge className="bg-emerald-700 hover:bg-emerald-700"><CheckCircle2 className="mr-1 h-3 w-3" /> Confirmado</Badge>}
                  {p.cancelled && <Badge variant="destructive">Cancelada</Badge>}
                </div>
                <h2 className="mt-3 text-sm font-bold">{p.number || p.process_number || 'Processo não identificado'}</h2>
                <p className="mt-1 text-xs text-muted-foreground">{[p.tribunal || p.court, p.orgao, `Disponibilização ${brDate(p.availability_date)}`].filter(Boolean).join(' · ')}</p>
                {p.expand?.process?.title && <p className="mt-1 text-xs text-primary">Vinculado: {p.expand.process.title}</p>}
              </div>
              {p.link && <Button asChild size="sm" variant="outline"><a href={p.link} target="_blank" rel="noopener noreferrer"><ExternalLink className="mr-1 h-4 w-4" /> Original</a></Button>}
            </div>

            <div className="mt-4 rounded-xl bg-secondary/45 p-4">
              <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground"><Scale className="h-4 w-4" /> Resumo da publicação</p>
              <p className="mt-2 text-sm leading-relaxed">{p.summary || 'Sem resumo.'}</p>
              {p.action_reason && <p className="mt-2 text-xs text-muted-foreground"><strong>É para agir?</strong> {p.action_reason}</p>}
              {p.parties && <p className="mt-2 whitespace-pre-line text-xs text-muted-foreground"><strong>Destinatários/partes identificadas no DJEN:</strong> {p.parties}</p>}
            </div>

            {p.action_required !== 'nao' ? (
              <div className="mt-4 grid gap-3 rounded-xl border border-border p-4 lg:grid-cols-[1fr_150px_170px_auto] lg:items-end">
                <div>
                  <p className="text-xs font-semibold">Rascunho do prazo</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {p.deadline ? `Publicação: ${brDate(p.publication_date || p.published_at)} · Vencimento calculado: ${brDate(p.deadline)} · ${String(p.regime || 'cpc').toUpperCase()}` : 'O texto não permitiu identificar automaticamente a quantidade de dias.'}
                  </p>
                  {!p.process && <p className="mt-1 flex items-center gap-1 text-xs text-amber-700"><AlertTriangle className="h-3 w-3" /> Processo ainda não cadastrado/vinculado. O prazo pode ir à agenda, mas o cadastro processual deve ser associado.</p>}
                </div>
                <div className="space-y-1"><Label className="text-xs">Dias úteis</Label><Input type="number" min="1" max="365" value={editDays[p.id] ?? ''} onChange={(e) => setEditDays({ ...editDays, [p.id]: e.target.value })} /></div>
                <Button variant="outline" onClick={() => recalc(p)} disabled={busyId === p.id}><Clock3 className="mr-1 h-4 w-4" /> Recalcular</Button>
                <div className="flex gap-2">
                  <Button onClick={() => confirm(p)} disabled={!p.deadline || p.deadline_status === 'confirmado' || busyId === p.id}><CalendarCheck className="mr-1 h-4 w-4" /> Confirmar</Button>
                  <Button variant="ghost" onClick={() => ignore(p)} disabled={busyId === p.id} title="Não é para agir"><XCircle className="h-4 w-4" /></Button>
                </div>
              </div>
            ) : (
              <div className="mt-4 flex items-center gap-2 rounded-xl border border-border bg-secondary/30 p-3 text-xs text-muted-foreground"><CheckCircle2 className="h-4 w-4" /> Esta publicação não gerou prazo na agenda.</div>
            )}

            <details className="mt-4 text-xs text-muted-foreground">
              <summary className="cursor-pointer font-medium">Ver teor recebido do DJEN</summary>
              <p className="mt-2 max-h-56 overflow-auto whitespace-pre-wrap rounded-xl bg-secondary/40 p-3 leading-relaxed">{p.raw || 'Sem teor armazenado.'}</p>
            </details>
          </article>
        ))}
      </div>

      <section className="rounded-2xl border border-border bg-card p-5">
        <h2 className="font-display text-lg font-bold">Feriados e indisponibilidades</h2>
        <p className="mt-1 text-xs text-muted-foreground">Os feriados nacionais fixos e o recesso de 20/12 a 20/01 já são tratados pelo motor. Cadastre aqui feriados específicos do tribunal, da comarca e suspensões locais.</p>
        <form onSubmit={saveHoliday} className="mt-4 grid gap-3 md:grid-cols-6 md:items-end">
          <div className="space-y-1"><Label>Data</Label><Input type="date" value={holidayForm.date} onChange={(e) => setHolidayForm({ ...holidayForm, date: e.target.value })} required /></div>
          <div className="space-y-1 md:col-span-2"><Label>Descrição</Label><Input value={holidayForm.name} onChange={(e) => setHolidayForm({ ...holidayForm, name: e.target.value })} placeholder="Feriado municipal / suspensão" required /></div>
          <div className="space-y-1"><Label>Abrangência</Label><Select value={holidayForm.scope} onValueChange={(v) => setHolidayForm({ ...holidayForm, scope: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="nacional">Nacional</SelectItem><SelectItem value="tribunal">Tribunal</SelectItem><SelectItem value="comarca">Comarca</SelectItem></SelectContent></Select></div>
          <div className="space-y-1"><Label>{holidayForm.scope === 'comarca' ? 'Comarca' : 'Tribunal'}</Label><Input value={holidayForm.scope === 'comarca' ? holidayForm.comarca : holidayForm.tribunal} onChange={(e) => holidayForm.scope === 'comarca' ? setHolidayForm({ ...holidayForm, comarca: e.target.value }) : setHolidayForm({ ...holidayForm, tribunal: e.target.value })} placeholder={holidayForm.scope === 'comarca' ? 'Governador Valadares' : 'TJMG'} /></div>
          <Button type="submit">Adicionar</Button>
        </form>
        <div className="mt-4 divide-y divide-border rounded-xl border border-border">
          {holidays.length === 0 && <p className="p-4 text-xs text-muted-foreground">Nenhum feriado local cadastrado.</p>}
          {holidays.map((h) => <div key={h.id} className="flex items-center justify-between gap-3 p-3 text-sm"><span><strong>{brDate(h.date)}</strong> — {h.name} <span className="text-xs text-muted-foreground">({h.scope}{h.comarca ? ` · ${h.comarca}` : ''}{h.tribunal ? ` · ${h.tribunal}` : ''})</span></span><Button size="icon" variant="ghost" onClick={() => removeHoliday(h.id)}><Trash2 className="h-4 w-4" /></Button></div>)}
        </div>
      </section>
    </div>
  );
}
