import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import pb from '@/lib/pocketbaseClient';
import apiServerClient from '@/lib/apiServerClient';
import { useAuth } from '@/contexts/AuthContext';
import { fmtDate, fmtDateTime, fmtBRL, toPbDate, toPbDateOnly, APPT_CATEGORIES } from '@/lib/site';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  Plus, Trash2, Pencil, CalendarDays, LayoutDashboard,
  CheckCircle2, Circle, KeyRound, CalendarPlus, Download,
  ChevronLeft, ChevronRight, Loader2, RefreshCw,
} from 'lucide-react';

const ROLES = [
  { value: 'owner', label: 'Owner (proprietário)' },
  { value: 'admin', label: 'Administrador' },
  { value: 'financeiro', label: 'Financeiro' },
  { value: 'operacional', label: 'Operacional' },
  { value: 'leitura', label: 'Somente leitura' },
];
const ROLE_LABEL = Object.fromEntries(ROLES.map((r) => [r.value, r.label]));

/* ============================ Usuários ============================ */

const EMPTY_USER = { name: '', email: '', role: 'operacional', password: '', active: true, oab_number: '', oab_uf: '' };

export function AdminUsers() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_USER);
  const [error, setError] = useState('');
  const [pwOpen, setPwOpen] = useState(null);
  const [newPw, setNewPw] = useState('');

  const load = useCallback(() => {
    pb.collection('users').getFullList({ sort: 'name' }).then(setUsers).catch(() => setUsers([]));
  }, []);
  useEffect(load, [load]);

  const openNew = () => { setEditing(null); setForm(EMPTY_USER); setError(''); setOpen(true); };
  const openEdit = (u) => {
    setEditing(u);
    setForm({ name: u.name || '', email: u.email || '', role: u.role || 'leitura', password: '', active: u.active !== false, oab_number: u.oab_number || '', oab_uf: u.oab_uf || '' });
    setError('');
    setOpen(true);
  };

  const save = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (editing) {
        const data = { name: form.name, role: form.role, active: !!form.active, oab_number: form.oab_number, oab_uf: form.oab_uf.toUpperCase().slice(0, 2) };
        if (form.password) { data.password = form.password; data.passwordConfirm = form.password; }
        await pb.collection('users').update(editing.id, data);
      } else {
        await pb.collection('users').create({
          name: form.name, email: form.email, role: form.role, active: !!form.active,
          oab_number: form.oab_number, oab_uf: form.oab_uf.toUpperCase().slice(0, 2),
          password: form.password, passwordConfirm: form.password, verified: true,
        });
      }
      setOpen(false);
      load();
    } catch (err) {
      setError(err?.message || 'Não foi possível salvar (e-mail único; senha 10+ caracteres).');
    }
  };

  const toggleActive = async (u) => {
    await pb.collection('users').update(u.id, { active: u.active === false });
    load();
  };

  const resetPw = async () => {
    if (!pwOpen || newPw.length < 10) { setError('A senha precisa de 10+ caracteres.'); return; }
    try {
      await pb.collection('users').update(pwOpen.id, { password: newPw, passwordConfirm: newPw });
      setPwOpen(null); setNewPw(''); setError('');
    } catch (err) {
      setError(err?.message || 'Não foi possível redefinir a senha.');
    }
  };

  const remove = async (u) => {
    if (u.id === me?.id) { window.alert('Você não pode excluir sua própria conta.'); return; }
    if (!window.confirm(`Excluir o usuário ${u.name || u.email}?`)) return;
    await pb.collection('users').delete(u.id);
    load();
  };

  return (
    <div>
      <Helmet><title>Usuários — Área Restrita</title><meta name="description" content="Gestão de usuários e permissões." /></Helmet>
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight">Usuários e permissões</h1>
          <p className="mt-1 text-sm text-muted-foreground">Equipe interna com acesso à área restrita.</p>
        </div>
        <Button onClick={openNew}><Plus className="mr-1 h-4 w-4" /> Novo usuário</Button>
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead className="hidden sm:table-cell">E-mail</TableHead>
              <TableHead>Perfil</TableHead>
              <TableHead className="hidden md:table-cell">OAB</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users === null && <TableRow><TableCell colSpan={6} className="text-muted-foreground">Carregando…</TableCell></TableRow>}
            {users !== null && users.length === 0 && <TableRow><TableCell colSpan={6} className="text-muted-foreground">Nenhum usuário.</TableCell></TableRow>}
            {(users || []).map((u) => (
              <TableRow key={u.id}>
                <TableCell className="font-medium">{u.name || '—'}{u.id === me?.id && <span className="ml-2 text-xs text-muted-foreground">(você)</span>}</TableCell>
                <TableCell className="hidden sm:table-cell">{u.email}</TableCell>
                <TableCell><Badge variant="outline">{ROLE_LABEL[u.role] || u.role || '—'}</Badge></TableCell>
                <TableCell className="hidden md:table-cell text-xs text-muted-foreground">{u.oab_number ? `${u.oab_number}/${u.oab_uf || ''}` : '—'}</TableCell>
                <TableCell>
                  <Badge className={u.active !== false ? 'bg-primary/10 text-primary border-0 hover:bg-primary/10' : 'bg-muted text-muted-foreground border-0 hover:bg-muted'}>
                    {u.active !== false ? 'Ativo' : 'Inativo'}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" aria-label="Editar" onClick={() => openEdit(u)}><Pencil className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" aria-label="Redefinir senha" onClick={() => { setPwOpen(u); setNewPw(''); setError(''); }}><KeyRound className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" aria-label="Ativar/desativar" onClick={() => toggleActive(u)}><CheckCircle2 className="h-4 w-4" /></Button>
                  <Button variant="ghost" size="icon" aria-label="Excluir" onClick={() => remove(u)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? 'Editar usuário' : 'Novo usuário'}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-4">
            <div className="space-y-2"><Label>Nome</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="space-y-2"><Label>E-mail</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required disabled={!!editing} /></div>
            <div className="space-y-2">
              <Label>Perfil de acesso</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ROLES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="col-span-2 space-y-2">
                <Label>OAB (número)</Label>
                <Input value={form.oab_number} onChange={(e) => setForm({ ...form, oab_number: e.target.value })} placeholder="123456" />
              </div>
              <div className="space-y-2">
                <Label>UF</Label>
                <Input value={form.oab_uf} onChange={(e) => setForm({ ...form, oab_uf: e.target.value.toUpperCase().slice(0, 2) })} placeholder="MG" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">A OAB identifica o advogado responsável pelos processos.</p>
            <div className="space-y-2">
              <Label>{editing ? 'Nova senha (deixe em branco para manter)' : 'Senha (mín. 10 caracteres)'}</Label>
              <Input type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required={!editing} minLength={editing ? 0 : 10} />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={!!form.active} onCheckedChange={(v) => setForm({ ...form, active: !!v })} /> Ativo
            </label>
            {error && <p className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full">Salvar</Button>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!pwOpen} onOpenChange={(v) => !v && setPwOpen(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Redefinir senha — {pwOpen?.name || pwOpen?.email}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Nova senha (mín. 10 caracteres)</Label><Input type="text" value={newPw} onChange={(e) => setNewPw(e.target.value)} /></div>
            {error && <p className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
            <Button className="w-full" onClick={resetPw}>Redefinir</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Permissões e visibilidade de dados */}
      <div className="mt-10 rounded-2xl border border-border bg-card p-6">
        <h2 className="font-display text-lg font-bold">Permissões e visibilidade de dados</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Cada usuário enxerga somente os processos, lançamentos financeiros, pendências, compromissos e
          apontamentos dos quais é responsável. Somente o <strong>administrador master (Owner)</strong> vê
          todos os registros do escritório. O isolamento é enforced pelas regras de acesso do banco de dados.
        </p>
        <div className="mt-4 overflow-x-auto rounded-xl border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Perfil</TableHead>
                <TableHead>Processos</TableHead>
                <TableHead>Financeiro / Livros</TableHead>
                <TableHead>Auditoria / LGPD</TableHead>
                <TableHead>Criar registros</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">Owner (master)</TableCell>
                <TableCell>Todos</TableCell>
                <TableCell>Todos</TableCell>
                <TableCell>Sim</TableCell>
                <TableCell>Sim</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Administrador</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>—</TableCell>
                <TableCell>Sim</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Financeiro</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>—</TableCell>
                <TableCell>Sim</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Operacional</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>—</TableCell>
                <TableCell>Sim</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">Somente leitura</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>Somente os seus</TableCell>
                <TableCell>—</TableCell>
                <TableCell>—</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Todas as criações, edições e exclusões continuam registradas no log de auditoria imutável.
        </p>
      </div>
    </div>
  );
}

/* ============================ Auditoria ============================ */

export function AdminAudit() {
  const [rows, setRows] = useState(null);
  const [lgpd, setLgpd] = useState([]);
  const [col, setCol] = useState('all');
  const [action, setAction] = useState('all');
  const [expanded, setExpanded] = useState(null);

  const load = useCallback(() => {
    let filter = '';
    const parts = [];
    if (col !== 'all') parts.push(`collection = "${col}"`);
    if (action !== 'all') parts.push(`action = "${action}"`);
    if (parts.length) filter = parts.join(' && ');
    pb.collection('audit_logs').getList(1, 100, { sort: '-created', filter, expand: 'actor' })
      .then((r) => setRows(r.items)).catch(() => setRows([]));
    pb.collection('lgpd_logs').getList(1, 50, { sort: '-created' })
      .then((r) => setLgpd(r.items)).catch(() => setLgpd([]));
  }, [col, action]);
  useEffect(load, [load]);

  const cols = ['posts', 'clients', 'processes', 'events', 'documents', 'pendencias', 'appointments', 'financial', 'ledger', 'funnels', 'funnel_stages', 'bio_links', 'users', 'notifications', 'site_settings', 'subtasks'];

  const pretty = (s) => {
    if (!s) return '—';
    try { return JSON.stringify(JSON.parse(s), null, 2); } catch (_) { return s; }
  };

  return (
    <div>
      <Helmet><title>Auditoria — Área Restrita</title><meta name="description" content="Histórico de alterações no sistema." /></Helmet>
      <h1 className="font-display text-2xl font-bold tracking-tight">Auditoria</h1>
      <p className="mt-1 text-sm text-muted-foreground">Histórico imutável de criações, edições e exclusões (antes/depois).</p>
      <div className="mt-4 flex flex-wrap gap-3">
        <Select value={col} onValueChange={setCol}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Coleção" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as coleções</SelectItem>
            {cols.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={action} onValueChange={setAction}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Ação" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as ações</SelectItem>
            <SelectItem value="create">Criação</SelectItem>
            <SelectItem value="update">Edição</SelectItem>
            <SelectItem value="delete">Exclusão</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead className="hidden sm:table-cell">Usuário</TableHead>
              <TableHead>Ação</TableHead>
              <TableHead>Coleção</TableHead>
              <TableHead>Registro</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows === null && <TableRow><TableCell colSpan={5} className="text-muted-foreground">Carregando…</TableCell></TableRow>}
            {rows !== null && rows.length === 0 && <TableRow><TableCell colSpan={5} className="text-muted-foreground">Nenhum registro.</TableCell></TableRow>}
            {(rows || []).map((r) => (
              <React.Fragment key={r.id}>
                <TableRow className="cursor-pointer hover:bg-secondary/50" onClick={() => setExpanded(expanded === r.id ? null : r.id)}>
                  <TableCell className="whitespace-nowrap text-xs">{fmtDateTime(r.created)}</TableCell>
                  <TableCell className="hidden sm:table-cell">{r.expand?.actor?.name || r.expand?.actor?.email || '—'}</TableCell>
                  <TableCell>
                    <Badge className={
                      r.action === 'create' ? 'bg-primary/10 text-primary border-0 hover:bg-primary/10'
                      : r.action === 'delete' ? 'bg-destructive/10 text-destructive border-0 hover:bg-destructive/10'
                      : 'bg-accent/15 text-accent border-0 hover:bg-accent/15'
                    }>{r.action}</Badge>
                  </TableCell>
                  <TableCell className="text-xs">{r.collection}</TableCell>
                  <TableCell className="font-mono text-xs">{r.record_id}</TableCell>
                </TableRow>
                {expanded === r.id && (
                  <TableRow>
                    <TableCell colSpan={5} className="bg-secondary/30">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div>
                          <p className="mb-1 text-xs font-bold uppercase tracking-widest text-muted-foreground">Antes</p>
                          <pre className="max-h-72 overflow-auto rounded-lg bg-background p-3 text-xs">{pretty(r.before)}</pre>
                        </div>
                        <div>
                          <p className="mb-1 text-xs font-bold uppercase tracking-widest text-muted-foreground">Depois</p>
                          <pre className="max-h-72 overflow-auto rounded-lg bg-background p-3 text-xs">{pretty(r.after)}</pre>
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="mt-10 rounded-2xl border border-border bg-card p-6">
        <h2 className="font-display text-lg font-bold">Registro LGPD</h2>
        <p className="mt-1 text-sm text-muted-foreground">Operações com dados pessoais realizadas pelo cliente via portal (ex.: upload de documentos).</p>
        <div className="mt-4 overflow-x-auto rounded-xl border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Quem</TableHead>
                <TableHead>Ação</TableHead>
                <TableHead>Coleção</TableHead>
                <TableHead>Detalhe</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {lgpd.length === 0 && <TableRow><TableCell colSpan={5} className="text-muted-foreground">Nenhum registro LGPD.</TableCell></TableRow>}
              {lgpd.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="whitespace-nowrap text-xs">{fmtDateTime(l.created)}</TableCell>
                  <TableCell className="text-sm">{l.actor || '—'}</TableCell>
                  <TableCell><Badge variant="outline">{l.action}</Badge></TableCell>
                  <TableCell className="text-xs">{l.collection_name || '—'}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{l.detail || '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

function downloadCSV(filename, rows) {
  const csv = rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export function AdminDRE() {
  const [ledger, setLedger] = useState([]);
  const [financial, setFinancial] = useState([]);
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [book, setBook] = useState('all');

  useEffect(() => {
    pb.collection('ledger').getFullList({ sort: '-date' }).then(setLedger).catch(() => setLedger([]));
    pb.collection('financial').getFullList({ expand: 'client' }).then(setFinancial).catch(() => setFinancial([]));
  }, []);

  const filtered = useMemo(() => {
    const within = (date) => {
      if (from && date && date < toPbDate(from)) return false;
      if (to && date && date > toPbDate(to)) return false;
      return true;
    };
    const ledgerRows = ledger.filter((r) => (book !== 'all' && r.book !== book ? false : within(r.date)));
    // Inclui honorários/despesas dos casos (financial) no DRE do escritório
    const finRows = financial
      .filter((f) => within(f.due || f.created))
      .map((f) => ({ ...f, date: f.due || f.created, type: f.type === 'despesa' || f.type === 'custas' ? 'despesa' : 'receita', category: 'Honorários do caso', book: 'escritorio' }));
    return [...ledgerRows, ...finRows];
  }, [ledger, financial, from, to, book]);

  const dre = useMemo(() => {
    const byCat = {};
    let receita = 0, despesa = 0, prolabore = 0, transferencia = 0;
    filtered.forEach((r) => {
      const a = Number(r.amount) || 0;
      if (r.status !== 'pago') return;
      const cat = r.category || 'Sem categoria';
      byCat[cat] = (byCat[cat] || 0) + a;
      if (r.type === 'receita') receita += a;
      else if (r.type === 'despesa') despesa += a;
      else if (r.type === 'prolabore') prolabore += a;
      else if (r.type === 'transferencia') transferencia += a;
    });
    return { byCat, receita, despesa, prolabore, transferencia, resultado: receita - despesa - prolabore };
  }, [filtered]);

  const monthly = useMemo(() => {
    const m = {};
    filtered.forEach((r) => {
      if (!r.date) return;
      const key = String(r.date).slice(0, 7);
      if (!m[key]) m[key] = { receita: 0, despesa: 0, prolabore: 0, transferencia: 0 };
      const a = Number(r.amount) || 0;
      if (r.status !== 'pago') return;
      if (r.type === 'receita') m[key].receita += a;
      else if (r.type === 'despesa') m[key].despesa += a;
      else if (r.type === 'prolabore') m[key].prolabore += a;
      else if (r.type === 'transferencia') m[key].transferencia += a;
    });
    return Object.entries(m).sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [filtered]);

  const receivables = useMemo(() => {
    let aReceber = 0, recebido = 0, vencido = 0;
    financial.forEach((f) => {
      const a = Number(f.amount) || 0;
      if (f.status === 'pago') recebido += a;
      else if (f.status === 'vencido') { vencido += a; aReceber += a; }
      else if (f.status === 'pendente') aReceber += a;
    });
    return { aReceber, recebido, vencido };
  }, [financial]);

  const exportDRE = () => {
    const rows = [['DRE — Demonstrativo', ''], ['Período', `${from || 'início'} a ${to || 'hoje'}`], ['Livro', book === 'all' ? 'Todos' : book], []];
    rows.push(['Receitas pagas', dre.receita], ['Despesas pagas', dre.despesa], ['Pró-labore', dre.prolabore], ['Transferências', dre.transferencia], ['Resultado', dre.resultado], []);
    rows.push(['Por categoria', '']);
    Object.entries(dre.byCat).forEach(([k, v]) => rows.push([k, v]));
    rows.push([], ['Mês', 'Receita', 'Despesa', 'Pró-labore', 'Transferência']);
    monthly.forEach(([k, v]) => rows.push([k, v.receita, v.despesa, v.prolabore, v.transferencia]));
    downloadCSV(`dre-${Date.now()}.csv`, rows);
  };

  return (
    <div>
      <Helmet><title>DRE & Relatórios — Área Restrita</title><meta name="description" content="Demonstrativo financeiro e relatórios." /></Helmet>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-bold tracking-tight">DRE & Relatórios</h1>
        <Button variant="outline" onClick={exportDRE}><Download className="mr-1 h-4 w-4" /> Exportar CSV</Button>
      </div>
      <div className="mt-4 flex flex-wrap items-end gap-3 rounded-2xl border border-border bg-card p-4">
        <div className="space-y-2"><Label>De</Label><Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></div>
        <div className="space-y-2"><Label>Até</Label><Input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
        <div className="space-y-2">
          <Label>Livro</Label>
          <Select value={book} onValueChange={setBook}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="escritorio">Escritório</SelectItem>
              <SelectItem value="pessoal">Pessoal / Pró-labore</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Receitas pagas', value: dre.receita, cls: 'text-primary' },
          { label: 'Despesas pagas', value: dre.despesa, cls: 'text-destructive' },
          { label: 'Pró-labore', value: dre.prolabore, cls: 'text-accent' },
          { label: 'Resultado', value: dre.resultado, cls: dre.resultado >= 0 ? 'text-primary' : 'text-destructive' },
        ].map((m) => (
          <div key={m.label} className="rounded-2xl border border-border bg-card p-5">
            <p className="text-xs text-muted-foreground">{m.label}</p>
            <p className={`font-display mt-2 text-2xl font-bold ${m.cls}`}>{fmtBRL(m.value)}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display font-bold">Despesas por categoria</h2>
          <ul className="mt-4 space-y-2 text-sm">
            {Object.entries(dre.byCat).filter(([, v]) => v).length === 0 && <li className="text-muted-foreground">Sem dados no período.</li>}
            {Object.entries(dre.byCat).sort((a, b) => b[1] - a[1]).map(([k, v]) => (
              <li key={k} className="flex items-center justify-between border-b border-border pb-2">
                <span>{k}</span><span className="font-medium">{fmtBRL(v)}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="font-display font-bold">Contas a receber (clientes)</h2>
          <ul className="mt-4 space-y-2 text-sm">
            <li className="flex items-center justify-between border-b border-border pb-2"><span>Total a receber</span><span className="font-medium text-accent">{fmtBRL(receivables.aReceber)}</span></li>
            <li className="flex items-center justify-between border-b border-border pb-2"><span>Vencido</span><span className="font-medium text-destructive">{fmtBRL(receivables.vencido)}</span></li>
            <li className="flex items-center justify-between"><span>Recebido</span><span className="font-medium text-primary">{fmtBRL(receivables.recebido)}</span></li>
          </ul>
        </div>
      </div>

      <div className="mt-8 overflow-x-auto rounded-2xl border border-border bg-card">
        <Table>
          <TableHeader><TableRow><TableHead>Mês</TableHead><TableHead className="text-right">Receita</TableHead><TableHead className="text-right">Despesa</TableHead><TableHead className="text-right">Pró-labore</TableHead><TableHead className="text-right">Transferência</TableHead><TableHead className="text-right">Resultado</TableHead></TableRow></TableHeader>
          <TableBody>
            {monthly.length === 0 && <TableRow><TableCell colSpan={6} className="text-muted-foreground">Sem lançamentos no período.</TableCell></TableRow>}
            {monthly.map(([k, v]) => (
              <TableRow key={k}>
                <TableCell className="font-medium">{k}</TableCell>
                <TableCell className="text-right">{fmtBRL(v.receita)}</TableCell>
                <TableCell className="text-right">{fmtBRL(v.despesa)}</TableCell>
                <TableCell className="text-right">{fmtBRL(v.prolabore)}</TableCell>
                <TableCell className="text-right">{fmtBRL(v.transferencia)}</TableCell>
                <TableCell className="text-right font-semibold">{fmtBRL(v.receita - v.despesa - v.prolabore)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

/* ============================ Agenda + Tarefas ============================ */

function gcalLink(title, startISO, durationMin, description, location) {
  if (!startISO) return '';
  const dt = new Date(String(startISO).replace(' ', 'T'));
  if (Number.isNaN(dt.getTime())) return '';
  const end = new Date(dt.getTime() + (durationMin || 60) * 60000);
  const fmt = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const p = (s) => encodeURIComponent(s || '');
  return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${p(title)}&dates=${fmt(dt)}/${fmt(end)}&details=${p(description)}&location=${p(location)}`;
}

function GoogleCalendarSync({ onSynced }) {
  const [status, setStatus] = useState(null);
  const [token, setToken] = useState(null);
  const [calendars, setCalendars] = useState([]);
  const [selectedCal, setSelectedCal] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [synced, setSynced] = useState(null);

  useEffect(() => {
    apiServerClient.fetch('/gcal/status').then((r) => r.json()).then(setStatus).catch(() => setStatus(null));
  }, []);

  const loadGis = () => new Promise((resolve) => {
    if (window.google?.accounts?.oauth2) return resolve();
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client';
    s.async = true; s.defer = true;
    s.onload = () => resolve();
    document.head.appendChild(s);
  });

  const connect = async () => {
    if (!status?.clientId) return;
    setBusy(true); setErr('');
    try {
      await loadGis();
      const tokenClient = window.google.accounts.oauth2.initTokenClient({
        client_id: status.clientId,
        scope: 'https://www.googleapis.com/auth/calendar.readonly',
        callback: async (resp) => {
          if (resp.error) { setErr(String(resp.error)); setBusy(false); return; }
          setToken(resp.access_token);
          try {
            const r = await apiServerClient.fetch('/gcal/calendars', {
              method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ token: resp.access_token }),
            });
            const data = await r.json();
            if (!r.ok) throw new Error(data.error?.message || 'Erro ao listar agendas');
            setCalendars(data.items || []);
            if (data.items?.[0]) setSelectedCal(data.items[0].id);
          } catch (e) { setErr(e.message || 'Erro ao listar agendas'); }
          setBusy(false);
        },
      });
      tokenClient.requestAccessToken();
    } catch (e) {
      setErr(e.message || 'Erro ao conectar');
      setBusy(false);
    }
  };

  const sync = async () => {
    if (!token || !selectedCal) return;
    setBusy(true); setErr('');
    try {
      const now = new Date();
      const timeMin = now.toISOString();
      const timeMax = new Date(now.getTime() + 90 * 86400000).toISOString();
      const r = await apiServerClient.fetch('/gcal/events', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, calendarId: selectedCal, timeMin, timeMax }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error?.message || 'Erro ao buscar eventos');
      const events = data.items || [];
      let added = 0;
      for (const ev of events) {
        const start = ev.start?.dateTime || ev.start?.date;
        if (!start) continue;
        const dateStr = String(start).replace('T', ' ').slice(0, 19);
        const title = ev.summary || '(sem título)';
        let exists = false;
        try {
          const found = await pb.collection('appointments').getList(1, 1, {
            filter: pb.filter('title = {:t} && date = {:d}', { t: title, d: dateStr }),
          });
          exists = found.items?.length > 0;
        } catch (_) {}
        if (exists) continue;
        try {
          await pb.collection('appointments').create({
            title, date: dateStr, location: ev.location || '',
            notes: ev.description || '', category: 'reuniao',
            meet_link: ev.hangoutLink || '', visible: false,
          }, { requestKey: `gcal-${ev.id}` });
          added++;
        } catch (_) {}
      }
      setSynced({ total: events.length, added });
      if (onSynced) onSynced();
    } catch (e) {
      setErr(e.message || 'Erro ao sincronizar');
    } finally {
      setBusy(false);
    }
  };

  const disconnect = () => {
    if (window.google?.accounts?.oauth2 && token) {
      try { window.google.accounts.oauth2.revoke(token, () => {}); } catch (_) {}
    }
    setToken(null); setCalendars([]); setSelectedCal(''); setSynced(null);
  };

  if (!status) return null;

  if (!status.configured) {
    return (
      <div className="space-y-2 rounded-2xl border border-border bg-secondary/30 p-4 text-sm">
        <p className="font-display flex items-center gap-2 font-semibold"><CalendarPlus className="h-4 w-4" /> Sincronização com Google Agenda</p>
        <div className="rounded-xl border border-accent/30 bg-accent/5 p-3 text-xs text-accent">
          ○ Não configurado. Para sincronizar com o Google Agenda é necessário criar um projeto no
          Google Cloud Console, habilitar a <strong>Google Calendar API</strong> e criar uma credencial
          OAuth 2.0 (tipo "Aplicativo da Web") com a URL deste site como origem autorizada (JavaScript).
          Em seguida, informe o <strong>Client ID OAuth</strong> no servidor — variável
          <code> GOOGLE_OAUTH_CLIENT_ID</code> no arquivo <code>apps/api/.env</code>.
        </div>
        <p className="text-xs text-muted-foreground">Após configurar, o botão "Conectar" fará o login OAuth real com a sua conta Google e listará suas agendas.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3 rounded-2xl border border-border bg-secondary/30 p-4 text-sm">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="flex items-center gap-2 text-muted-foreground"><CalendarPlus className="h-4 w-4" /> Sincronização com Google Agenda</span>
        {token ? (
          <Badge className="border-0 bg-primary/10 text-primary hover:bg-primary/10">Conectado</Badge>
        ) : (
          <Button size="sm" variant="outline" onClick={connect} disabled={busy}>
            {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <CalendarPlus className="mr-1 h-4 w-4" />} Conectar Google Agenda
          </Button>
        )}
      </div>
      {err && <p className="text-xs text-destructive">{err}</p>}
      {token && (
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Agenda</Label>
            <Select value={selectedCal} onValueChange={setSelectedCal}>
              <SelectTrigger><SelectValue placeholder="Selecionar agenda" /></SelectTrigger>
              <SelectContent>
                {calendars.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.summary || c.id}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={sync} disabled={busy || !selectedCal}>
              {busy ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-1 h-4 w-4" />} Importar próximos 90 dias
            </Button>
            <Button size="sm" variant="ghost" onClick={disconnect}>Desconectar</Button>
          </div>
          {synced && <p className="text-xs text-muted-foreground">{synced.total} evento(s) encontrado(s) · {synced.added} importado(s) como compromissos.</p>}
        </div>
      )}
    </div>
  );
}

export function AdminAgenda() {
  const [appts, setAppts] = useState([]);
  const [events, setEvents] = useState([]);
  const [pendencias, setPendencias] = useState([]);
  const [djenDrafts, setDjenDrafts] = useState([]);
  const [subMap, setSubMap] = useState({});
  const [newSub, setNewSub] = useState({});
  const [tab, setTab] = useState('agenda');
  const [calView, setCalView] = useState('mes'); // mes | semana | dia
  const [cursor, setCursor] = useState(new Date());

  const load = useCallback(() => {
    pb.collection('appointments').getFullList({ sort: 'date', expand: 'client' }).then(setAppts).catch(() => setAppts([]));
    pb.collection('events').getFullList({ sort: 'date', expand: 'process' }).then(setEvents).catch(() => setEvents([]));
    pb.collection('pendencias').getFullList({ sort: 'due', expand: 'process' }).then(setPendencias).catch(() => setPendencias([]));
    pb.collection('djen_publications').getFullList({ sort: 'deadline', filter: 'deadline_status = \"rascunho\" && deadline != \"\"', expand: 'process' }).then(setDjenDrafts).catch(() => setDjenDrafts([]));
    pb.collection('subtasks').getFullList({ sort: 'order' }).then((subs) => {
      const map = {};
      subs.forEach((s) => { (map[s.pendencia] = map[s.pendencia] || []).push(s); });
      setSubMap(map);
    }).catch(() => setSubMap({}));
  }, []);
  useEffect(load, [load]);

  const upcoming = useMemo(() => {
    const now = Date.now();
    const items = [
      ...appts.map((a) => ({ kind: 'Compromisso', date: a.date, title: a.title, where: a.location, desc: a.notes, ref: a, gcal: gcalLink(a.title, a.date, 60, a.notes, a.location) })),
      ...events.map((e) => ({ kind: EVENT_LABEL[e.type] || 'Andamento', date: e.date, title: e.title, where: '', desc: e.description, ref: e, gcal: gcalLink(e.title, e.date, 60, e.description, '') })),
      ...djenDrafts.map((p) => ({ kind: 'Prazo DJEN · rascunho', date: p.deadline, title: `Prazo — ${p.number || p.process_number || 'DJEN'}`, where: '', desc: p.summary, ref: p, gcal: null })),
    ];
    return items.filter((i) => i.date).sort((a, b) => (a.date < b.date ? -1 : 1)).filter((i) => new Date(String(i.date).replace(' ', 'T')).getTime() >= now - 86400000).slice(0, 30);
  }, [appts, events, djenDrafts]);

  const addSub = async (pid) => {
    const title = (newSub[pid] || '').trim();
    if (!title) return;
    await pb.collection('subtasks').create({ pendencia: pid, title, done: false, order: (subMap[pid]?.length || 0) + 1 }, { requestKey: `sub-${pid}-${Date.now()}` });
    setNewSub({ ...newSub, [pid]: '' });
    load();
  };
  const toggleSub = async (s) => { await pb.collection('subtasks').update(s.id, { done: !s.done }); load(); };
  const delSub = async (s) => { await pb.collection('subtasks').delete(s.id); load(); };

  const openTasks = pendencias.filter((p) => !p.done);

  // Itens de calendário unificados (compromissos + eventos + prazos)
  const calItems = useMemo(() => {
    const items = [];
    appts.forEach((a) => items.push({ id: a.id, date: a.date, title: a.title, kind: 'Compromisso', category: a.category, meet_link: a.meet_link, where: a.location, desc: a.notes }));
    events.forEach((e) => items.push({ id: e.id, date: e.date, title: e.title, kind: EVENT_LABEL[e.type] || 'Andamento', category: e.type === 'audiencia' ? 'audiencia' : e.type === 'prazo' ? 'prazo' : null, where: '', desc: e.description }));
    pendencias.filter((p) => p.due).forEach((p) => items.push({ id: p.id, date: p.due, title: p.title, kind: 'Pendência', category: 'prazo', where: '', desc: p.description }));
    djenDrafts.filter((p) => p.deadline).forEach((p) => items.push({ id: `djen-${p.id}`, date: p.deadline, title: `Rascunho DJEN — ${p.number || p.process_number || 'processo'}`, kind: 'Prazo DJEN · rascunho', category: 'prazo', where: '', desc: p.summary }));
    return items;
  }, [appts, events, pendencias, djenDrafts]);

  const shiftCursor = (dir) => {
    const d = new Date(cursor);
    if (calView === 'mes') d.setMonth(d.getMonth() + dir);
    else if (calView === 'semana') d.setDate(d.getDate() + dir * 7);
    else d.setDate(d.getDate() + dir);
    setCursor(d);
  };
  const cursorLabel = () => {
    const d = cursor;
    const meses = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
    if (calView === 'mes') return `${meses[d.getMonth()]} ${d.getFullYear()}`;
    if (calView === 'semana') { const ini = startOfWeek(d); const fim = new Date(ini); fim.setDate(fim.getDate() + 6); return `${ini.getDate()}/${ini.getMonth() + 1} – ${fim.getDate()}/${fim.getMonth() + 1}/${fim.getFullYear()}`; }
    return d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  };

  return (
    <div>
      <Helmet><title>Agenda & Tarefas — Área Restrita</title><meta name="description" content="Agenda, compromissos e quadro de tarefas." /></Helmet>
      <h1 className="font-display text-2xl font-bold tracking-tight">Agenda & Tarefas</h1>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button size="sm" variant={tab === 'agenda' ? 'default' : 'outline'} onClick={() => setTab('agenda')}><CalendarDays className="mr-1 h-4 w-4" /> Agenda</Button>
        <Button size="sm" variant={tab === 'tarefas' ? 'default' : 'outline'} onClick={() => setTab('tarefas')}><LayoutDashboard className="mr-1 h-4 w-4" /> Tarefas</Button>
      </div>

      {tab === 'agenda' && (
        <div className="mt-6 space-y-4">
          {/* Barra de visualização do calendário */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-border bg-card p-3">
            <div className="flex items-center gap-2">
              <Button size="sm" variant="ghost" onClick={() => shiftCursor(-1)}><ChevronLeft className="h-4 w-4" /></Button>
              <span className="font-display min-w-[140px] text-center text-sm font-bold">{cursorLabel()}</span>
              <Button size="sm" variant="ghost" onClick={() => shiftCursor(1)}><ChevronRight className="h-4 w-4" /></Button>
              <Button size="sm" variant="outline" onClick={() => setCursor(new Date())}>Hoje</Button>
            </div>
            <div className="flex gap-1">
              {[['mes', 'Mês'], ['semana', 'Semana'], ['dia', 'Dia'], ['lista', 'Lista']].map(([v, l]) => (
                <Button key={v} size="sm" variant={calView === v ? 'default' : 'outline'} onClick={() => setCalView(v)}>{l}</Button>
              ))}
            </div>
          </div>

          {/* Integração Google Agenda */}
          <GoogleCalendarSync onSynced={load} />

          {calView === 'mes' && <MonthGrid cursor={cursor} items={calItems} onDay={(d) => { setCursor(d); setCalView('dia'); }} />}
          {calView === 'semana' && <WeekGrid cursor={cursor} items={calItems} />}
          {calView === 'dia' && <DayGrid cursor={cursor} items={calItems} />}

          {calView === 'lista' && (
            <div className="space-y-3">
              {upcoming.length === 0 && <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">Nenhum compromisso ou prazo futuro.</p>}
              {upcoming.map((i, idx) => (
                <div key={idx} className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4">
                  <div className="min-w-0">
                    <p className="text-xs text-muted-foreground">{fmtDateTime(i.date)} · <Badge variant="outline" className="ml-1">{i.kind}</Badge></p>
                    <p className="mt-1 text-sm font-semibold">{i.title}</p>
                    {i.where && <p className="text-xs text-muted-foreground">{i.where}</p>}
                    {i.desc && <p className="mt-1 text-xs text-muted-foreground">{i.desc}</p>}
                  </div>
                  {i.gcal && (
                    <Button asChild size="sm" variant="outline">
                      <a href={i.gcal} target="_blank" rel="noopener noreferrer"><CalendarPlus className="mr-1 h-4 w-4" /> Google Agenda</a>
                    </Button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'tarefas' && (
        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {openTasks.length === 0 && <p className="col-span-full rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">Nenhuma pendência em aberto.</p>}
          {openTasks.map((p) => (
            <div key={p.id} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{p.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.expand?.process?.title ? <Link to={`/restrito/painel/processos/${p.expand.process.id}`} className="text-primary hover:underline">{p.expand.process.title}</Link> : '—'}
                    {p.due ? ` · prazo ${fmtDate(p.due)}` : ''}
                  </p>
                </div>
                <button aria-label="Concluir" onClick={async () => { await pb.collection('pendencias').update(p.id, { done: true }); load(); }}>
                  <Circle className="h-5 w-5 text-accent" />
                </button>
              </div>
              <ul className="mt-3 space-y-1.5 border-t border-border pt-3">
                {(subMap[p.id] || []).map((s) => (
                  <li key={s.id} className="flex items-center gap-2 text-sm">
                    <button aria-label="Alternar" onClick={() => toggleSub(s)}>
                      {s.done ? <CheckCircle2 className="h-4 w-4 text-primary" /> : <Circle className="h-4 w-4 text-muted-foreground" />}
                    </button>
                    <span className={s.done ? 'text-muted-foreground line-through' : ''}>{s.title}</span>
                    <button aria-label="Excluir subtarefa" className="ml-auto" onClick={() => delSub(s)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></button>
                  </li>
                ))}
              </ul>
              <div className="mt-3 flex gap-2">
                <Input
                  value={newSub[p.id] || ''}
                  onChange={(e) => setNewSub({ ...newSub, [p.id]: e.target.value })}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addSub(p.id); } }}
                  placeholder="Adicionar subtarefa…"
                  className="h-8 text-sm"
                />
                <Button size="sm" variant="outline" onClick={() => addSub(p.id)}><Plus className="h-4 w-4" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const EVENT_LABEL = { andamento: 'Andamento', audiencia: 'Audiência', prazo: 'Prazo', documento: 'Documento', outro: 'Outro' };

const DOW = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const MONTHS = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];

function startOfWeek(d) { const x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - x.getDay()); return x; }
function sameDay(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function itemDot(item) { const c = APPT_CATEGORIES[item.category]; return c ? c.dot : 'bg-muted-foreground'; }
function itemBadge(item) { const c = APPT_CATEGORIES[item.category]; return c ? c.cls : 'bg-muted text-muted-foreground'; }

function MonthGrid({ cursor, items, onDay }) {
  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const first = new Date(year, month, 1);
  const start = new Date(first); start.setDate(start.getDate() - first.getDay());
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const cells = Array.from({ length: 42 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d; });
  return (
    <div className="rounded-2xl border border-border bg-card p-2">
      <div className="grid grid-cols-7 gap-1">
        {DOW.map((d) => <div key={d} className="py-1 text-center text-[10px] font-bold uppercase tracking-widest text-muted-foreground">{d}</div>)}
        {cells.map((d, i) => {
          const dayItems = items.filter((it) => it.date && sameDay(new Date(String(it.date).replace(' ', 'T')), d));
          const inMonth = d.getMonth() === month;
          return (
            <button key={i} type="button" onClick={() => onDay(d)} className={`min-h-[84px] rounded-lg border p-1.5 text-left transition-colors ${inMonth ? 'border-border bg-background hover:border-primary/40' : 'border-transparent bg-secondary/30 text-muted-foreground'} ${sameDay(d, today) ? 'ring-1 ring-primary' : ''}`}>
              <span className={`text-xs font-semibold ${sameDay(d, today) ? 'text-primary' : ''}`}>{d.getDate()}</span>
              <div className="mt-1 space-y-0.5">
                {dayItems.slice(0, 3).map((it) => (
                  <div key={it.id} className="flex items-center gap-1 truncate text-[10px]">
                    <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${itemDot(it)}`} />
                    <span className="truncate">{it.title}</span>
                  </div>
                ))}
                {dayItems.length > 3 && <span className="text-[10px] text-muted-foreground">+{dayItems.length - 3}</span>}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function WeekGrid({ cursor, items }) {
  const ini = startOfWeek(cursor);
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(ini); d.setDate(ini.getDate() + i); return d; });
  const today = new Date(); today.setHours(0, 0, 0, 0);
  return (
    <div className="grid grid-cols-1 gap-2 sm:grid-cols-7">
      {days.map((d, i) => {
        const dayItems = items.filter((it) => it.date && sameDay(new Date(String(it.date).replace(' ', 'T')), d)).sort((a, b) => (a.date < b.date ? -1 : 1));
        return (
          <div key={i} className={`min-h-[180px] rounded-xl border p-2 ${sameDay(d, today) ? 'border-primary/50 bg-primary/5' : 'border-border bg-card'}`}>
            <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">{DOW[d.getDay()]} {d.getDate()}</p>
            <div className="space-y-1.5">
              {dayItems.map((it) => (
                <div key={it.id} className="rounded-lg bg-secondary/60 p-1.5 text-xs">
                  <div className="flex items-center gap-1">
                    <span className={`h-2 w-2 shrink-0 rounded-full ${itemDot(it)}`} />
                    <span className="truncate font-semibold">{it.title}</span>
                  </div>
                  <p className="mt-0.5 text-[10px] text-muted-foreground">{fmtDateTime(it.date).split(' ')[1] || ''} · {it.kind}</p>
                </div>
              ))}
              {dayItems.length === 0 && <p className="text-[10px] text-muted-foreground">—</p>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function DayGrid({ cursor, items }) {
  const d = new Date(cursor); d.setHours(0, 0, 0, 0);
  const dayItems = items.filter((it) => it.date && sameDay(new Date(String(it.date).replace(' ', 'T')), d)).sort((a, b) => (a.date < b.date ? -1 : 1));
  const hours = Array.from({ length: 12 }, (_, i) => 8 + i); // 08:00 – 19:00
  return (
    <div className="rounded-2xl border border-border bg-card">
      <div className="border-b border-border p-3 text-sm font-semibold">{cursor.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}</div>
      <div className="divide-y divide-border">
        {hours.map((h) => {
          const slot = dayItems.filter((it) => { const dt = new Date(String(it.date).replace(' ', 'T')); return dt.getHours() === h; });
          return (
            <div key={h} className="flex gap-3 p-3">
              <span className="w-14 shrink-0 font-mono text-xs text-muted-foreground">{String(h).padStart(2, '0')}:00</span>
              <div className="flex-1 space-y-1.5">
                {slot.map((it) => (
                  <div key={it.id} className="rounded-lg border border-border bg-secondary/40 p-2 text-sm">
                    <div className="flex items-center gap-2">
                      <Badge className={`${itemBadge(it)} hover:${itemBadge(it)} border-0`}>{it.kind}</Badge>
                      <span className="font-semibold">{it.title}</span>
                    </div>
                    {it.where && <p className="mt-1 text-xs text-muted-foreground">{it.where}</p>}
                    {it.meet_link && <a href={it.meet_link} target="_blank" rel="noopener noreferrer" className="mt-1 inline-block text-xs text-primary hover:underline">Entrar na sala virtual →</a>}
                    {it.desc && <p className="mt-1 text-xs text-muted-foreground">{it.desc}</p>}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
        {dayItems.filter((it) => { const dt = new Date(String(it.date).replace(' ', 'T')); return dt.getHours() < 8 || dt.getHours() > 19; }).map((it) => (
          <div key={it.id} className="flex gap-3 p-3">
            <span className="w-14 shrink-0 font-mono text-xs text-muted-foreground">—</span>
            <div className="flex-1 rounded-lg border border-border bg-secondary/40 p-2 text-sm">
              <span className="font-semibold">{it.title}</span> <span className="text-xs text-muted-foreground">{fmtDateTime(it.date)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================ CMS — conteúdo do site ============================ */

const CMS_FIELDS = [
  { key: 'hero_title', label: 'Título do hero (home)', type: 'text' },
  { key: 'hero_subtitle', label: 'Subtítulo do hero (home)', type: 'textarea' },
  { key: 'about_teaser', label: 'Texto de apresentação (home)', type: 'textarea' },
  { key: 'areas_intro', label: 'Título da seção de áreas', type: 'text' },
  { key: 'blog_intro', label: 'Título da seção do blog', type: 'text' },
  { key: 'footer_about', label: 'Texto do rodapé', type: 'textarea' },
  { key: 'contact_whatsapp', label: 'WhatsApp (somente dígitos, com DDI)', type: 'text' },
  { key: 'contact_email', label: 'E-mail de contato', type: 'text' },
  { key: 'contact_instagram', label: 'Instagram (URL)', type: 'text' },
];

export function AdminCMS() {
  const [values, setValues] = useState({});
  const [msg, setMsg] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    pb.collection('site_settings').getFullList().then((rows) => {
      const map = {};
      rows.forEach((r) => { map[r.key] = r; });
      setValues(map);
    }).catch(() => setValues({}));
  }, []);

  const val = (key) => values[key]?.value || '';
  const set = (key, v) => setValues((prev) => ({ ...prev, [key]: { ...(prev[key] || {}), value: v } }));

  const save = async (e) => {
    e.preventDefault();
    setSaving(true); setMsg('');
    try {
      await Promise.all(CMS_FIELDS.map((f, i) => {
        const existing = values[f.key];
        const v = val(f.key);
        if (existing?.id) {
          return pb.collection('site_settings').update(existing.id, { value: v }, { requestKey: `cms-${f.key}-${i}` });
        }
        return pb.collection('site_settings').create({ key: f.key, value: v }, { requestKey: `cms-${f.key}-${i}` });
      }));
      setMsg('Conteúdo salvo. As alterações aparecem no site público.');
    } catch (err) {
      setMsg(err?.message || 'Erro ao salvar.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <Helmet><title>Conteúdo do site — Área Restrita</title><meta name="description" content="Editor de conteúdo do site." /></Helmet>
      <h1 className="font-display text-2xl font-bold tracking-tight">Conteúdo do site</h1>
      <p className="mt-1 text-sm text-muted-foreground">Edite textos exibidos no site público. As mudanças são aplicadas imediatamente.</p>
      <form onSubmit={save} className="mt-6 max-w-2xl space-y-5 rounded-2xl border border-border bg-card p-6">
        {CMS_FIELDS.map((f) => (
          <div key={f.key} className="space-y-2">
            <Label>{f.label}</Label>
            {f.type === 'textarea'
              ? <Textarea rows={3} value={val(f.key)} onChange={(e) => set(f.key, e.target.value)} />
              : <Input value={val(f.key)} onChange={(e) => set(f.key, e.target.value)} />}
          </div>
        ))}
        {msg && <p className="text-sm text-muted-foreground">{msg}</p>}
        <Button type="submit" disabled={saving}>{saving ? 'Salvando…' : 'Salvar conteúdo'}</Button>
      </form>
    </div>
  );
}


