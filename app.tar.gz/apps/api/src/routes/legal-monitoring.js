import { Router } from 'express';
import pb from '../utils/pocketbaseClient.js';
import { requirePocketBaseUser } from '../middleware/pocketbase-user.js';
import {
  calculateProceduralDeadline,
  datesForDjenDailyWindow,
  fetchDatajudProcess,
  fetchDjenByOab,
  fetchDjenProcessMetadata,
  normalizeCnj,
  toPocketBaseDate,
} from '../utils/legalMonitoring.js';

const router = Router();
router.use(requirePocketBaseUser);

function userCanAccess(record, user) {
  return user?.role === 'owner' || record?.responsible === user?.id || record?.responsible_user === user?.id;
}

async function holidaysFor({ userId, tribunal = '', comarca = '' }) {
  try {
    const rows = await pb.collection('court_holidays').getFullList({ sort: 'date' });
    return rows.filter((h) => {
      if (h.active === false) return false;
      if (h.responsible_user && h.responsible_user !== userId) return false;
      if (h.scope === 'tribunal' && h.tribunal && String(h.tribunal).toUpperCase() !== String(tribunal).toUpperCase()) return false;
      if (h.scope === 'comarca' && h.comarca && String(h.comarca).toLowerCase() !== String(comarca).toLowerCase()) return false;
      return true;
    }).map((h) => h.date);
  } catch {
    return [];
  }
}

async function matchProcess(user, processNumber) {
  if (!processNumber) return null;
  const target = String(processNumber).replace(/\D/g, '');
  if (!target) return null;
  try {
    const rows = await pb.collection('processes').getFullList({ fields: 'id,number,responsible,client,comarca,vara,tribunal' });
    return rows.find((p) => String(p.number || '').replace(/\D/g, '') === target && userCanAccess(p, user)) || null;
  } catch {
    return null;
  }
}

router.get('/datajud/process/:cnj', async (req, res, next) => {
  try {
    const [result, djenMeta] = await Promise.all([
      fetchDatajudProcess(req.params.cnj),
      fetchDjenProcessMetadata(req.params.cnj).catch(() => null),
    ]);
    if (result.found) {
      const pubs = await pb.collection('djen_publications').getFullList({ fields: 'number,process_number,parties,responsible_user' }).catch(() => []);
      const digits = result.cnjDigits;
      const partySet = new Set(djenMeta?.parties || []);
      pubs.filter((p) => (!p.responsible_user || p.responsible_user === req.authUser.id) && String(p.process_number || p.number || '').replace(/\D/g, '') === digits)
        .forEach((p) => String(p.parties || '').split('\n').map((s) => s.trim()).filter(Boolean).forEach((s) => partySet.add(s)));
      if (partySet.size) {
        result.parties = [...partySet];
        result.partiesSource = 'djen';
        result.partiesUnavailableReason = '';
      }
      if (!result.tribunal && djenMeta?.tribunal) result.tribunal = djenMeta.tribunal;
      if (!result.courtUnit && djenMeta?.courtUnit) result.courtUnit = djenMeta.courtUnit;
      if (!result.class && djenMeta?.className) result.class = djenMeta.className;
      result.djenPublicationsFound = Number(djenMeta?.count || 0);
    }
    res.json(result);
  } catch (error) { next(error); }
});

router.post('/datajud/import', async (req, res, next) => {
  try {
    const { processId, cnj } = req.body || {};
    if (!processId || !cnj) return res.status(400).json({ error: 'processId e cnj são obrigatórios.' });
    const process = await pb.collection('processes').getOne(processId);
    if (!userCanAccess(process, req.authUser)) return res.status(403).json({ error: 'Sem acesso a este processo.' });
    const result = await fetchDatajudProcess(cnj);
    if (!result.found) return res.status(404).json({ error: 'Processo não localizado no DataJud.', result });

    const summaryParts = [result.class, result.subjects?.length ? `Assuntos: ${result.subjects.join(', ')}` : '', result.parties?.length ? `Partes: ${result.parties.join('; ')}` : ''].filter(Boolean);
    await pb.collection('processes').update(process.id, {
      number: result.cnj,
      tribunal: result.tribunal || process.tribunal || '',
      vara: result.courtUnit || process.vara || '',
      parties: result.parties?.join('\n') || process.parties || '',
      datajud_synced_at: new Date().toISOString(),
      summary: process.summary || summaryParts.join('\n'),
    });

    const existing = await pb.collection('events').getFullList({ filter: `process = "${process.id}"`, fields: 'external_id' }).catch(() => []);
    const seen = new Set(existing.map((e) => e.external_id).filter(Boolean));
    const pendingMovements = result.movements.slice(0, 500).filter((mov) => !seen.has(mov.externalId));
    let imported = 0;
    let cursor = 0;
    const concurrency = Math.min(12, Math.max(1, pendingMovements.length));
    const workers = Array.from({ length: concurrency }, async () => {
      while (cursor < pendingMovements.length) {
        const index = cursor;
        cursor += 1;
        const mov = pendingMovements[index];
        const descriptionBits = [mov.code ? `Código CNJ ${mov.code}` : '', mov.courtUnit || '', mov.complements?.length ? JSON.stringify(mov.complements) : ''].filter(Boolean);
        try {
          await pb.collection('events').create({
            process: process.id,
            date: mov.date || new Date().toISOString(),
            title: mov.name || 'Movimentação processual',
            description: descriptionBits.join(' · '),
            type: 'andamento',
            source: 'datajud',
            external_id: mov.externalId,
          });
          imported += 1;
        } catch (error) {
          // Corrida ou reimportação simultânea: o índice único é a última barreira contra duplicidade.
          if (!String(error?.message || '').toLowerCase().includes('unique')) throw error;
        }
      }
    });
    await Promise.all(workers);
    res.json({ ok: true, imported, totalAvailable: result.movements.length, process: result });
  } catch (error) { next(error); }
});

router.post('/deadline/calculate', async (req, res, next) => {
  try {
    const { availabilityDate, days, regime = 'cpc', tribunal = '', comarca = '' } = req.body || {};
    const holidays = await holidaysFor({ userId: req.authUser.id, tribunal, comarca });
    res.json(calculateProceduralDeadline({ availabilityDate, days: Number(days), regime, holidays }));
  } catch (error) { next(error); }
});

router.post('/djen/sync', async (req, res, next) => {
  try {
    const user = req.authUser;
    const oab = String(user?.oab_number || '').trim();
    const uf = String(user?.oab_uf || '').trim().toUpperCase();
    if (!oab || !uf) return res.status(400).json({ error: 'Cadastre sua OAB e UF no usuário antes da sincronização.' });
    const window = datesForDjenDailyWindow();
    const startDate = req.body?.startDate || window.startDate;
    const endDate = req.body?.endDate || window.endDate;
    const items = await fetchDjenByOab({ oab, uf, startDate, endDate, maxItems: Math.min(500, Number(req.body?.maxItems) || 500) });
    const saved = [];
    for (const item of items) {
      const process = await matchProcess(user, item.processNumber);
      let calc = null;
      if (item.actionRequired !== 'nao' && item.deadlineDays && item.availabilityDate) {
        const holidays = await holidaysFor({ userId: user.id, tribunal: item.tribunal, comarca: process?.comarca || '' });
        calc = calculateProceduralDeadline({ availabilityDate: item.availabilityDate, days: item.deadlineDays, regime: item.regime, holidays });
      }
      const payload = {
        process: process?.id || '',
        number: item.processNumber || '',
        parties: item.parties.join('\n'),
        court: item.tribunal || '',
        published_at: calc?.publicationDate ? toPocketBaseDate(calc.publicationDate) : toPocketBaseDate(item.availabilityDate),
        summary: item.summary,
        raw: item.rawText,
        status: item.actionRequired === 'nao' ? 'ignorado' : (process ? 'associado' : 'pendente'),
        deadline: calc?.deadlineDate ? toPocketBaseDate(calc.deadlineDate, '18:00:00') : '',
        external_id: item.externalId,
        source_hash: item.hash,
        tribunal: item.tribunal,
        orgao: item.courtUnit,
        process_number: item.processNumber,
        availability_date: toPocketBaseDate(item.availabilityDate),
        publication_date: calc?.publicationDate ? toPocketBaseDate(calc.publicationDate) : '',
        action_required: item.actionRequired,
        action_reason: item.actionReason,
        urgency: item.urgency,
        deadline_days: item.deadlineDays || 0,
        deadline_kind: item.deadlineKind,
        regime: item.regime,
        deadline_status: calc ? 'rascunho' : 'sem_prazo',
        responsible_user: user.id,
        link: item.link,
        cancelled: item.cancelled,
        cancel_reason: item.cancelReason,
      };
      let record = null;
      const escapedId = String(item.externalId).replace(/"/g, '\\"');
      const existing = await pb.collection('djen_publications').getList(1, 1, { filter: `responsible_user = "${user.id}" && external_id = "${escapedId}"` }).then((r) => r.items[0]).catch(() => null);
      if (existing) record = await pb.collection('djen_publications').update(existing.id, payload);
      else record = await pb.collection('djen_publications').create(payload);
      saved.push(record);
    }
    res.json({ ok: true, startDate, endDate, found: items.length, saved: saved.length });
  } catch (error) { next(error); }
});

router.post('/djen/:id/recalculate', async (req, res, next) => {
  try {
    const pub = await pb.collection('djen_publications').getOne(req.params.id, { expand: 'process' });
    if (!userCanAccess(pub, req.authUser)) return res.status(403).json({ error: 'Sem acesso a esta publicação.' });
    const days = Number(req.body?.days || pub.deadline_days);
    const regime = req.body?.regime || pub.regime || 'cpc';
    const availabilityDate = req.body?.availabilityDate || pub.availability_date;
    const process = pub.expand?.process || null;
    const holidays = await holidaysFor({ userId: req.authUser.id, tribunal: pub.tribunal, comarca: process?.comarca || '' });
    const calc = calculateProceduralDeadline({ availabilityDate, days, regime, holidays });
    const updated = await pb.collection('djen_publications').update(pub.id, {
      deadline_days: days,
      regime,
      publication_date: toPocketBaseDate(calc.publicationDate),
      deadline: toPocketBaseDate(calc.deadlineDate, '18:00:00'),
      deadline_status: 'rascunho',
      action_required: 'sim',
      status: pub.process ? 'associado' : 'pendente',
    });
    res.json({ ok: true, calculation: calc, publication: updated });
  } catch (error) { next(error); }
});

router.post('/djen/:id/confirm', async (req, res, next) => {
  try {
    const pub = await pb.collection('djen_publications').getOne(req.params.id, { expand: 'process' });
    if (!userCanAccess(pub, req.authUser)) return res.status(403).json({ error: 'Sem acesso a esta publicação.' });
    if (!pub.deadline) return res.status(400).json({ error: 'Esta publicação ainda não possui prazo calculado.' });
    const process = pub.expand?.process || (pub.process ? await pb.collection('processes').getOne(pub.process) : null);
    const client = process?.client || '';
    const deadlineOwner = pub.responsible_user || req.authUser.id;
    const appointment = await pb.collection('appointments').create({
      client,
      process: process?.id || '',
      responsible: deadlineOwner,
      date: pub.deadline,
      title: `Prazo — ${pub.number || pub.process_number || 'DJEN'}`,
      notes: `${pub.summary || 'Prazo confirmado a partir de publicação do DJEN.'}\nPublicação DJEN: ${pub.id}`,
      category: 'prazo',
      sync_gcal: false,
      authorized_client: false,
      djen_publication: pub.id,
    });
    if (process?.id) {
      await pb.collection('deadlines').create({
        process: process.id,
        type: pub.regime === 'clt' ? 'Prazo processual (CLT)' : 'Prazo processual (CPC)',
        days_kind: 'uteis',
        days: Number(pub.deadline_days) || 0,
        initial_date: pub.publication_date || pub.published_at,
        calculated_date: pub.deadline,
        confirmed_date: pub.deadline,
        suspended: false,
        responsible_user: deadlineOwner,
        status: 'confirmado',
        notes: `Origem: DJEN ${pub.external_id || pub.id}`,
      });
    }
    await pb.collection('djen_publications').update(pub.id, { deadline_status: 'confirmado', status: process ? 'associado' : 'pendente' });
    res.json({ ok: true, appointment });
  } catch (error) { next(error); }
});

router.post('/djen/:id/ignore', async (req, res, next) => {
  try {
    const pub = await pb.collection('djen_publications').getOne(req.params.id);
    if (!userCanAccess(pub, req.authUser)) return res.status(403).json({ error: 'Sem acesso a esta publicação.' });
    const updated = await pb.collection('djen_publications').update(pub.id, { action_required: 'nao', deadline_status: 'sem_prazo', deadline: '', status: 'ignorado' });
    res.json({ ok: true, publication: updated });
  } catch (error) { next(error); }
});

export default router;
