// GET /gcal/status — reports whether Google Calendar OAuth is configured.
// The GOOGLE_OAUTH_CLIENT_ID is a user-supplied value (created in Google Cloud
// Console). It is safe to expose to the browser because web-app OAuth client
// IDs are public by design — only the user's own consent grants access.
import { isIntegrationConfigured } from "../utils/integrationConfig.js";

export default (req, res) => {
  const clientId = process.env.GOOGLE_OAUTH_CLIENT_ID || "";
  res.json({
    configured: isIntegrationConfigured("GOOGLE_OAUTH_CLIENT_ID"),
    clientId,
  });
};
