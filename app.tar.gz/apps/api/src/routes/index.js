import { Router } from 'express';
import healthCheck from './health-check.js';
import gcalStatus from './gcal-status.js';
import gcalCalendars from './gcal-calendars.js';
import gcalEvents from './gcal-events.js';
import legalMonitoring from './legal-monitoring.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);

    // Google Agenda — OAuth (Google Identity Services) + proxy de API
    router.get('/gcal/status', gcalStatus);
    router.post('/gcal/calendars', gcalCalendars);
    router.post('/gcal/events', gcalEvents);

    // DJEN + DataJud + cálculo de prazo
    router.use('/legal', legalMonitoring);

    return router;
};

